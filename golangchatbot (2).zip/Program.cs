﻿using System;
using System.Media;

namespace golangchatbot
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "golangchatbot";

            ShowGreeting();
            PlayVoiceGreeting();
            ShowAsciiArt();
            StartChat();

            Console.ReadKey();
        }

        //  Friendly Greeting
        static void ShowGreeting()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("=========================================");
            Console.WriteLine("       Welcome to golangchatbot");
            Console.WriteLine("=========================================\n");
            Console.ResetColor();
        }

        // GolangChatbot Voice Greeting 
        static void PlayVoiceGreeting()
        {
            try
            {
                SoundPlayer player = new SoundPlayer("C:\\Users\\Student\\source\\repos\\golangchatbot\\golang chatbot greetings.wav");
                player.PlaySync();
            }
            catch
            {
                Console.Beep(800, 300);
            }
        }

        // ascii art
        static void ShowAsciiArt()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(@"
   ____       _                             _           _   
  / ___| ___ | | __ _ _ __   __ _  ___  ___| |__   __ _| |_ 
 | |  _ / _ \| |/ _` | '_ \ / _` |/ _ \/ __| '_ \ / _` | __|
 | |_| | (_) | | (_| | | | | (_| |  __/ (__| | | | (_| | |_ 
  \____|\___/|_|\__,_|_| |_|\__, |\___|\___|_| |_|\__,_|\__|
                           |___/                           

              g o l a n g c h a t b o t
         CYBER SECURITY AWARENESS CHATBOT
");
            Console.ResetColor();
        }

        // 🔹 4. Chat Loop
        static void StartChat()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Ask me about: password, phishing, malware, privacy, scams");
            Console.WriteLine("Type 'exit' to quit.\n");
            Console.ResetColor();

            while (true)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("You: ");

                string input = Console.ReadLine()?.ToLower().Trim();

                // 🔹 5. Input Validation
                if (string.IsNullOrEmpty(input))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Bot: Please enter a valid question.\n");
                    Console.ResetColor();
                    continue;
                }

                // Exit
                if (input == "exit")
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("Bot: Goodbye! Stay safe online.");
                    break;
                }

                Respond(input);
            }
        }

        // 🔹 6. Predefined Cybersecurity Responses
        static void Respond(string input)
        {
            Console.ForegroundColor = ConsoleColor.Magenta;

            if (input.Contains("password"))
            {
                Console.WriteLine("Bot: Use strong passwords with uppercase, lowercase, numbers, and symbols. Do not reuse passwords.\n");
            }
            else if (input.Contains("phishing"))
            {
                Console.WriteLine("Bot: Phishing is a cyber attack where attackers trick you into giving personal information using fake emails or websites.\n");
            }
            else if (input.Contains("malware"))
            {
                Console.WriteLine("Bot: Malware is harmful software like viruses, spyware, and ransomware that can damage your system.\n");
            }
            else if (input.Contains("privacy"))
            {
                Console.WriteLine("Bot: Protect your privacy by limiting personal information shared online and using secure platforms.\n");
            }
            else if (input.Contains("scam"))
            {
                Console.WriteLine("Bot: Scams attempt to steal your money or data. Always verify links, emails, and calls before trusting them.\n");
            }
            else
            {
                Console.WriteLine("Bot: I don't understand. Please ask about password, phishing, malware, privacy or scams.\n");
            }

            Console.ResetColor();
        }
    }
}