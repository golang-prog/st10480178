﻿

namespace assienment__P2_
{
    public partial class Form1 : Form
    {
        // =========================================
        // VARIABLES
        // =========================================

        Random random = new Random();

       

        string lastTopic = "";
        string userName = "";
        string favouriteTopic = "";

        // =========================================
        // KEYWORD RESPONSES
        // =========================================

        Dictionary<string, List<string>> responses =
            new Dictionary<string, List<string>>()
        {
            {
                "hello",
                new List<string>()
                {
                    "Hello!",
                    "Hi there!",
                    "Welcome!",
                    "Good day!"
                }
            },

            {
                "how are you",
                new List<string>()
                {
                    "I am doing well!",
                    "I am fine today.",
                    "I am great and ready to help."
                }
            },

            {
                "password",
                new List<string>()
                {
                    "Use strong passwords with numbers and symbols.",
                    "Never use your birthday as a password.",
                    "Use a different password for every account."
                }
            },

            {
                "phishing",
                new List<string>()
                {
                    "Never click suspicious email links.",
                    "Scammers pretend to be trusted companies.",
                    "Always verify email senders before opening attachments."
                }
            },

            {
                "privacy",
                new List<string>()
                {
                    "Check your privacy settings regularly.",
                    "Avoid sharing personal information online.",
                    "Use two-factor authentication for better privacy."
                }
            },

            {
                "scam",
                new List<string>()
                {
                    "Online scams often create fake urgency.",
                    "Never send money to strangers online.",
                    "If something looks too good to be true, it probably is."
                }
            }
        };

        // =========================================
        // FORM
        // =========================================

        public Form1()
        {
            InitializeComponent();

            this.BackColor = Color.Black;

            listBox1.BackColor = Color.Black;
            listBox1.ForeColor = Color.Lime;

            textBox1.BackColor = Color.White;

            button1.BackColor = Color.LimeGreen;

            // ASCII ART
            listBox1.Items.Add("==================================");
            listBox1.Items.Add(" CYBERSECURITY AWARENESS CHATBOT ");
            listBox1.Items.Add("=================================="); 

            Speak("Welcome to the Cybersecurity Awareness Chatbot");

            listBox1.Items.Add("BOT: What is your name?");
        }

        // =========================================
        // SPEAK METHOD
        // =========================================

        private void Speak(string text)
        {
           
        }

        // =========================================
        // RANDOM RESPONSE METHOD
        // =========================================

        private string GetRandomResponse(string keyword)
        {
            List<string> replyList = responses[keyword];

            int index = random.Next(replyList.Count);

            return replyList[index];
        }

        // =========================================
        // MAIN RESPONSE METHOD
        // =========================================

        private string GetResponse(string input)
        {
            // =====================================
            // SAVE USER NAME
            // =====================================

            if (userName == "")
            {
                userName = input;
                return "Nice to meet you " + userName;
            }

            // =====================================
            // MEMORY FEATURE
            // =====================================

            if (input.Contains("interested in"))
            {
                if (input.Contains("privacy"))
                {
                    favouriteTopic = "privacy";
                }

                else if (input.Contains("password"))
                {
                    favouriteTopic = "password";
                }

                else if (input.Contains("phishing"))
                {
                    favouriteTopic = "phishing";
                }

                if (favouriteTopic != "")
                {
                    return "Great! I will remember that you like " +
                           favouriteTopic;
                }
            }

            // =====================================
            // SENTIMENT DETECTION
            // =====================================

            if (input.Contains("worried"))
            {
                return "It is understandable to feel worried. " +
                       "Cyber threats are real, but I can help you stay safe.";
            }

            if (input.Contains("frustrated"))
            {
                return "I understand cybersecurity can feel difficult sometimes. Let me help.";
            }

            if (input.Contains("curious"))
            {
                return "Curiosity is great when learning cybersecurity!";
            }

            // =====================================
            // CONVERSATION FLOW
            // =====================================

            if (input.Contains("more") ||
                input.Contains("another tip") ||
                input.Contains("tell me more"))
            {
                if (lastTopic != "")
                {
                    return GetRandomResponse(lastTopic);
                }
                else
                {
                    return "Please tell me which topic you want more information about.";
                }
            }

            // =====================================
            // KEYWORD RECOGNITION
            // =====================================

            foreach (var item in responses)
            {
                string keyword = item.Key;

                if (input.Contains(keyword))
                {
                    lastTopic = keyword;

                    string response = GetRandomResponse(keyword);

                    // PERSONALISED RESPONSE
                    if (keyword == favouriteTopic)
                    {
                        response +=
                            " Since this is your favourite topic, remember to keep learning about it.";
                    }

                    return response;
                }
            }

            // =====================================
            // EXIT
            // =====================================

            if (input == "exit")
            {
                Application.Exit();
            }

            // =====================================
            // DEFAULT ERROR MESSAGE
            // =====================================

            return "I do not understand. Please try again.";
        }

        // =========================================
        // BUTTON CLICK
        // =========================================

        private void button1_Click(object sender, EventArgs e)
        {
            string message = textBox1.Text.Trim().ToLower();

            if (string.IsNullOrEmpty(message))
            {
                MessageBox.Show("Type something first.");
                return;
            }

            // SHOW USER MESSAGE
            listBox1.Items.Add("YOU: " + message);

            // GET BOT RESPONSE
            string response = GetResponse(message);

            // SHOW BOT RESPONSE
            listBox1.Items.Add("BOT: " + response);

            // VOICE
            Speak(response);

            // CLEAR TEXTBOX
            textBox1.Clear();

            textBox1.Focus();
        }
    }
}